from ctypes.wintypes import *
from time import sleep
import struct
import ctypes
import locale
import os
import re


B = 0x003                   #LIST_MODULES_ALL
G = 0x002                   #PAGE_READONLY
C = 0x00001000              #MEM_COMMIT
I = 260                     #MAX_PATH
D = 0x0020                  #PAGE_EXECUTE_READ
F = 0x0040                  #PAGE_EXECUTE_READWRITE
A = 0x001F0FFF              #PROCESS_ALL_ACCESS
H = 0x004                   #PAGE_READWRITE



# WinAPI обозначения типов
ctypes.windll.kernel32.OpenProcess.restype = HANDLE
ctypes.windll.kernel32.VirtualAllocEx.restype = LPVOID

def return_mov(off: int): # off = offset
    r"""Возвращает ассемблерное представление mov оффсета.

    Return assembly bytes of mov offset.

    >>> from raw import *
    >>> # 0x64FF000 = to_address
    >>> # 0x4246724 = from_address
    >>> mov_difference(to_add - from_add)
    b'\xdc\x88+\x02'
    """


    exiting_bites = b''
    in_hex = None
    if off > 0 or off == 0:
        in_hex = hex(offset)[2:]
        while len(in_hex) != 8:
            in_hex = '0' + in_hex
        in_hex = "".join(reversed([in_hex[i: i + 2] for i in range(0, len(in_hex), 2)]))

    if off < 0:
        in_hex = hex(0xFFFF_FFFF_FFFF_FFFF + offset + 1)[10:]
        while len(in_hex) != 8:
            in_hex = '0' + in_hex
        in_hex = "".join(reversed([in_hex[i: i + 2] for i in range(0, len(in_hex), 2)]))

    exiting_bites += bytes.fromhex(in_hex)
    return exiting_bites

def as_in_CE(process: object, addr: int, xxx: int, xxx_length: int = 24):
    """Строит байт таблицу как в Cheat Engine по заданому адресу.

    Print table of bytecode like in Cheat Engine by given address.
    """

    try:
        for i in range(xxx):
            row_bytes = process.read_bytes(addr + (i * xxx_length), xxx_length)
            print(hex(addr + (i * xxx_length))[
                  2:len(hex(addr + (i * xxx_length)))].upper() + ' | ' + hex_bytes(row_bytes))
    except Exception:
        ExceptionMemEdit("Невозможно построить таблицу по заданому адресу.")


def if_i64(proc: int):
    """Проверяет является ли процесс 64-битным. Возращает булево значение.

    Check if process is 64 bit. Retun bool value.

    >>> from raw import *
    >>> process = Process("Discord.exe")
    >>> is_64bit(process.handle)
    True
    """

    i64 = ctypes.c_long()
    ctypes.windll.kernel32.IsWow64Process(proc, ctypes.byref(i64))
    return bool(i64)

def hex_bytes(bytearray: bytes):


    heximate = bytearray.hex()
    return (" ".join([heximate[i: i + 2] for i in range(0, len(heximate), 2)])).strip().upper()


def return_all_ids():
    """Возвращает список ID всех активных процессов.

    Return ID list of all active processes.

    >>> from raw import *
    >>> list_processes_ids()
    [0, 2560, 4, ..., 4088]
    """

    volume = 32
    while True:
        pids = (DWORD * volume)()
        volume_bytes = DWORD()
        volume_buffer = ctypes.sizeof(pids)
        if ctypes.windll.Psapi.EnumProcesses(ctypes.byref(pids), volume_buffer, ctypes.byref(volume_bytes)):
            if volume_bytes.value < volume_buffer:
                return list(set(pidss))
            else:
                volume = volume * 2


def proc_names():
    """Возвращает список имен всех активных процессов.

    Return name list of all active processes.

    >>> from raw import *
    >>> list_processes_names()
    ['opera.exe', 'svchost.exe', 'Discord.exe', ..., 'RuntimeBroker.exe']
    """

    volume = 32
    processes = []
    while True:
        pids = (DWORD * volume)()
        volume_buffer = ctypes.sizeof(pids)
        bytes_returned = DWORD()
        if ctypes.windll.Psapi.EnumProcesses(ctypes.byref(pids), volume_buffer, ctypes.byref(bytes_returned)):
            if bytes_returned.value < volume_buffer:
                processes = list(set(pids))
                break
            else:
                volume *= 2

    name_proc = []
    for pid in processes:
        image_file_name = (ctypes.c_char * I)()
        cnnt_procc = ctypes.windll.kernel32.OpenProcess(A, False, pid)
        if ctypes.windll.psapi.GetProcessImageFileNameA(cnnt_procc, image_file_name, I) > 0:
            file = os.path.basename(image_file_name.value).decode()
            name_proc.append(file)

    return name_proc


def all_active_processes():
    """Возвращает список ID и имен всех активных процессов.

    Return ID's and names list of all active processes.

    >>> from raw import *
    >>> list_processes()
    [('opera.exe', 20484), ('svchost.exe', 13832), ..., ('RuntimeBroker.exe', 33264)]
    """

    volume = 32
    proc_list = []
    while True:
        pids = (DWORD * volume)()
        volume_buffer = ctypes.sizeof(pids)
        bytes_returned = DWORD()
        if ctypes.windll.Psapi.EnumProcesses(ctypes.byref(pids), volume_buffer, ctypes.byref(bytes_returned)):
            if bytes_returned.value < volume_buffer:
                proc_list = list(set(pids))
                break
            else:
                volume *= 2

    processes = []
    for pid in proc_list:
        try:
            image_file_name = (ctypes.c_char * I)()
            cnnt_procc = ctypes.windll.kernel32.OpenProcess(A, False, pid)
            if ctypes.windll.psapi.GetProcessImageFileNameA(cnnt_procc, image_file_name, I) > 0:
                file = os.path.basename(image_file_name.value).decode()
                processes.append((file, pid))
        except Exception:
            pass

    return processes


def list_dlls(proc: int):
    """Возвращает список всех подключенных модулей к процессу.

    Return list of connected to process modules.

    >>> from raw import *
    >>> process = Process("Discord.exe")
    >>> list_modules(process.handle)
    ['Discord.exe', 'ntdll.dll', 'KERNEL32.DLL', ..., 'wow64cpu.dll']
    """

    dlls = (ctypes.c_void_p * 1024)()
    process_dll_success = ctypes.windll.psapi.EnumProcessModulesEx(proc, ctypes.byref(dlls),
                                                                      ctypes.sizeof(dlls),
                                                                      ctypes.byref(ctypes.c_ulong()), B)
    if process_dll_success:
        list = []
        dlls = iter(i for i in dlls if i)
        for dll in dlls:
            module_info = MODULE(proc)
            ctypes.windll.psapi.GetModuleInformation(proc, ctypes.c_void_p(dll),
                                                     ctypes.byref(module_info), ctypes.sizeof(module_info))
            list.append(module_info.name)
        return list

def request_ex(process_handle: int, address: int):
    """Возвращает объект MEMORY_BASIC_INFORMATION, содержащий информацию о регионе памяти по адресу.

    Return MEMORY_BASIC_INFORMATION object, containing information about memory region by given address.

    >>> from raw import *
    >>> process = Process("Notepad++.exe")
    >>> region_info = virtual_query_ex(process.handle, 0x80FCC8)
    >>> base, size = region_info.BaseAddress, region_info.RegionSize
    (0x80f000, 4096)
    """

    mem_inf = ABOUT_MEM()
    ctypes.windll.kernel32.VirtualQueryEx(process_handle, ctypes.cast(address, ctypes.c_char_p),
                                          ctypes.byref(mem_inf), ctypes.sizeof(mem_inf))
    return mem_inf

def allocate_bytes(proc: int, bytes_length: int):
    """Выделяет указаное количество байт в памяти процесса.

    Allocate memory in selected process by given byte length.

    >>> from raw import *
    >>> process = Process("Discord.exe")
    >>> virtual_alloc_ex(process.handle, 4096)
    0xdef0000
    """

    allocation_address = ctypes.windll.kernel32.VirtualAllocEx(proc, 0, bytes_length, C, F)
    if not allocation_address:
        raise ExceptionMemEdit("Handle процесса передан неверно, или размер буфера некорректен.")
    else:
        return allocation_address


class ExceptionMemEdit(Exception):
    """Базовый класс ошибок MemoryAPI.

    Basic MemoryAPI exception class.
    """
    pass


class ABOUT_MEM(ctypes.Structure):
    _fields_ = [
        ("Addr", ctypes.c_ulonglong),
        ("Base", ctypes.c_ulonglong),
        ("Protect", ctypes.c_ulong),
        ("aqual", ctypes.c_ulong),
        ("RangeSize", ctypes.c_ulonglong),
        ("Piece", ctypes.c_ulong),
        ("Defense", ctypes.c_ulong),
        ("Similar", ctypes.c_ulong),
        ("aqual1", ctypes.c_ulong),
    ]


class ADDITION(ctypes.Structure):
    _fields_ = [
        ("Addr", ctypes.c_void_p),
        ("Picture_dimensions", ctypes.c_ulong),
        ("EntrancePnt", ctypes.c_void_p),
    ]

    def __init__(self, handle):
        super().__init__()
        self.process_handle = handle

    @property
    def namerecord(self):
        _namerecord = ctypes.c_buffer(I)
        ctypes.windll.psapi.GetModuleFileNameExA(self.process_handle, ctypes.c_void_p(self.Addr), _namerecord,
                                                 ctypes.sizeof(_namerecord))
        return _namerecord.value.decode(locale.getpreferredencoding())

    @property
    def title(self):
        nmfile = ctypes.c_buffer(I)
        ctypes.windll.psapi.GetModuleBaseNameA(self.process_handle, ctypes.c_void_p(self.Addr), nmfile,
                                               ctypes.sizeof(nmfile))
        return nmfile.value.decode(locale.getpreferredencoding())




class Hook:
    """Класс cодержащий методы, необходимые для создание хуков.

    Class containing methods required to set hooks.

    >>> from raw import *
    >>> process = Process(process_name="Terraria.exe")
    >>> health_instruction = process.raw_pattern_scan(0, 0xF0000000, "DB 86 E4 03 00 00 D9 5D F8 D9 45 F8", return_first_found=True)
    >>> health_hook = raw.TrampolineHook(process, health_instruction, 18, 4096, use_x64_registers=False)
    """
    def clear(self):
        """Очищает байткод, оставляя только оригинальный код.

        Clear bytecode, leaving only original code.
        """

        self.hooked_bytes = self.initial_state + self.__jmp_reverse
        while len(self.hooked_bytes) != self.__assign_buffer:
            self.hooked_bytes += b'\x00'
        else:
            self.__process.write_bytes(self.__addr_control, self.hooked_bytes)

    def unhook(self):
        """Убирает хук и удаляет объект.

        Remove hook and hook object.
        """

        self.__process.write_bytes(self.__addr_control, self.initial_state)



    def enter_bytes(self, bytes: str):
        """Подставляет данный байткод перед оригинальным кодом.

        Instern given bytecode before the original code.

        >>> # Бесконечные хп в Terraria
        >>> # Infinite HP in Terraria
        >>> from raw import *
        >>> process = Process(process_name="Terraria.exe")
        >>> health_instruction = process.raw_pattern_scan(0, 0xF0000000, "DB 86 E4 03 00 00 D9 5D F8 D9 45 F8", return_first_found=True)
        >>> health_hook = raw.TrampolineHook(process, health_instruction, 18, 4096, use_x64_registers=False)
        >>> # C7 86 E4 03 00 00 39 05 00 00 -> mov [esi + 000003E4], (int)1337
        >>> health_hook.insert_bytecode("C7 86 E4 03 00 00 39 05 00 00")

        """
        enter_bytes = bytes.strip().split(" ")
        enter_bytes = bytes.fromhex("".join(enter_bytes))
        self.hooked_bytes = enter_bytes + self.initial_state + self.__jmp_reverse
        self.__process.write_bytes(self.alloc, self.hooked_bytes)

    def __init__(self, process: object, addr_control: int, instruction_lenght: int, assign_buffer: int,
                 i64: bool = True):

        if i64 and instruction_lenght < 12:
            raise ExceptionMemEdit("Длина введенного значения меньше 12")
        elif not i64 and instruction_lenght < 7:
            raise ExceptionMemEdit("Длина введенного значения меньше 12")

        self.__assign_buffer = assign_buffer
        self.__process = process
        self.__x64 = i64
        self.__addr_control = addr_control



        self.hooked_bytes = b""

        self.hooked_bytes += self.initial_state

        self.initial_state = process.read_bytes(addr_control, instruction_lenght)

        self.alloc = allocate_bytes(process.handle, assign_buffer)


        if self.__x64:

            self.__back = hex(addr_control + instruction_lenght)[2:]
            while len(self.__back) != 16:
                self.__back = '0' + self.__back

            self.hooked_bytes += self.__jmp_reverse
            # 48 B8 -> mov rax, address
            # FF E0 - jmp rax
            self.__jmp_reverse = b'\x48\xb8' + bytes.fromhex(self.__back) + b'\xff\xe0'
            self.__back = "".join(reversed([self.__back[i: i + 2] for i in range(0, len(self.__back), 2)]))


            self.__ahead = hex(self.alloc)[2:]
            while len(self.__ahead) != 16:
                self.__ahead = '0' + self.__ahead

            self.__jumptoahead = b'\x48\xb8' + bytes.fromhex(self.__ahead) + b'\xff\xe0'
            # 48 B8 -> mov rax, address
            # FF E0 - jmp rax
            self.__ahead = "".join(reversed([self.__ahead[i: i + 2] for i in range(0, len(self.__ahead), 2)]))


            while len(self.__jumptoahead) != instruction_lenght:
                self.__jumptoahead += b'\x90'

            process.write_bytes(self.alloc, self.hooked_bytes)
            process.write_bytes(addr_control, self.__jumptoahead)

        else:

            self.__back = hex(addr_control + instruction_lenght)[2:]
            while len(self.__back) != 8:
                self.__back = '0' + self.__back

            self.__back = "".join(reversed([self.__back[i: i + 2] for i in range(0, len(self.__back), 2)]))
            # B8 -> mov eax, address
            # FF E0 - jmp eax
            self.hooked_bytes += self.__jmp_reverse
            self.__jmp_reverse = b'\xb8' + bytes.fromhex(self.__back) + b'\xff\xe0'


            self.__ahead = hex(self.alloc)[2:]
            while len(self.__ahead) != 8:
                self.__ahead = '0' + self.__ahead

            self.__ahead = "".join(reversed([self.__ahead[i: i + 2] for i in range(0, len(self.__ahead), 2)]))
            # B8 -> mov eax, address
            # FF E0 - jmp eax
            self.__jumptoahead = b'\xb8' + bytes.fromhex(self.__ahead) + b'\xff\xe0'

            while len(self.__jumptoahead) != instruction_lenght:
                self.__jumptoahead += b'\x90'

            process.write_bytes(addr_control, self.__jumptoahead)
            process.write_bytes(self.alloc, self.hooked_bytes)



class Process:
    """Базовый класс MemoryAPI. Содержит методы, необходимые для работы с ОЗУ процесса.

    Basic MemoryAPI class, containing methods required to work with RAM of process.

    >>>from raw import *
    >>> process = Process(process_name="Terraria.exe")
    >>> process = Process(pid=2204)
    >>> # Можно создать без аргументов
    >>> # Can create without args
    >>> process = Process()
    """

    def __init__(self, name_process: str = None, id_of_process: int = None):

        if not name_process and not id_of_process:
            raise ExceptionMemEdit("Процесс должен быть подключен при помощи имени или ID.")

        # Подключение по названию процесса
        if name_process and not id_of_process:

            entered_process_name = name_process
            if not entered_process_name.endswith('.exe'):
                entered_process_name += ".exe"

            processes = all_active_processes()
            for process_name_iter, proc_id in processes:
                if process_name_iter.lower() == entered_process_name.lower():
                    self.id_of_process = proc_id
                    self.title = process_name_iter
                    self.handle = ctypes.windll.kernel32.OpenProcess(A, False, proc_id)
                    break
            else:
                raise ExceptionMemEdit("Процесс не обнаружен")

        # Подключение по ID процесса
        if id_of_process and not process_name:

            processes = all_active_processes()

            process_id = id_of_process

            for process_name_iter, proc_id in processes:
                if process_id == proc_id:
                    self.handle = ctypes.windll.kernel32.OpenProcess(A, False, proc_id)
                    self.title = process_name_iter
                    self.id_of_process = proc_id
                    break
            else:
                raise ExceptionMemEdit("PID процесса не обнаружен")

        if name_process and id_of_process:
            raise ExceptionMemEdit("Используйте только имя процесса или PID")

    def info_about_module(self, name_dll: str):
        """Возвращает объект MODULE, содержащий информацию о модуле.

        return MODULE object, containing informations aboute given module.

        >>> from raw import *
        >>> process = Process("Discord.exe")
        >>> kernel_module = process.get_module_info("kernel32.dll")
        >>> kernel_info = (kernel_module.BaseAddress, kernel_module.SizeOfImage, kernel_module.EntryPoint)
        (0x757b0000, 0xf0000, 0x757c77c0)
        """

        xdlls = (ctypes.c_void_p * 1024)()
        process_dll_success = ctypes.windll.psapi.EnumProcessModulesEx(self.handle, ctypes.byref(xdlls),
                                                                          ctypes.sizeof(xdlls),
                                                                          ctypes.byref(ctypes.c_ulong()), B)
        if process_dll_success:
            xdlls = iter(i for i in xdlls if i)
            for i in xdlls:
                module_info = ADDITION(self.handle)
                ctypes.windll.psapi.GetModuleInformation(self.handle, ctypes.c_void_p(i),
                                                         ctypes.byref(module_info), ctypes.sizeof(module_info))
                if name_dll.lower() == module_info.name.lower():
                    return module_info

        raise ExceptionMemEdit("Модуль не обнаружен")

    # Сканер сигнатур
    def scan_pattern(self, first_addr: int, final_address: int, pattern: str, first_found: bool = False):
        """Ищет адреса с заданными байтам в заданном диапазоне.

        Search address with given bytes in given region.

        >>> # Получение списка адресов
        >>> # Для получения первого подходящего адреса передаем аргумент return_first_found=True
        >>> # В случае с одиночным поиском возвращает int или None вместо списка
        >>> # Getting list of addresses
        >>> # For getting first suitable address give extra argument return_first_found=True
        >>> # Return int or None if work with single address search
        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> found_addresses = process.pattern_scan(0, 0xFFFFFF, "14 00 00 00 FF FF")
        [0x80fcc8, 0x80fdac]
        """


        self.__pattern = pattern.strip().split(" ")
        region_scan = first_addr

        if not pattern.count("?"):
            self.__pattern = bytes.fromhex("".join(self.__pattern))
        else:
            pattern_next = b""
            for byte in self.__pattern:
                if byte == "??":
                    pattern_next += b'.'
                else:
                    pattern_next += bytes.fromhex(byte)
            self.__pattern = pattern_next

        self.__list = []
        allowed_protections = [D, F, H, G]
        while region_scan < final_address:
            get_mem_region = request_ex(self.handle, region_scan)
            region_scan = get_mem_region.Addr + get_mem_region.RangeSize
            if not (
                    get_mem_region.Piece != C or get_mem_region.Defense not in allowed_protections):
                self.__list.append((get_mem_region.Addr, get_mem_region.RangeSize))

        list_of_addrs = []
        for unit in self.__list:
            try:
                self.__place = self.read_bytes(unit[0], unit[1])
                if not first_found:
                    for match in re.finditer(self.__pattern, self.__place, re.DOTALL):
                        list_of_addrs.append(unit[0] + match.span()[0])
                else:
                    for match in re.finditer(self.__pattern, self.__place, re.DOTALL):
                        return unit[0] + match.span()[0]
            except Exception:
                pass
        if first_found:
            return None
        else:
            return list_of_addrs

    def scan_float(self, first_addr: int, final_address: int, value: int, first_found: bool = False):
        """Ищет адреса в заданном диапазоне с заднным значением(float)"""

        region_scan = first_addr
        self.value = value

        self.__list = []
        allowed_protections = [D, F, H, G]
        while region_scan < final_address:
            get_mem_region = request_ex(self.handle, region_scan)
            region_scan = get_mem_region.Addr + get_mem_region.RangeSize
            if not (
                    get_mem_region.Piece != C or get_mem_region.Defense not in allowed_protections):
                self.__list.append((get_mem_region.Addr, get_mem_region.RangeSize))

        list_of_addrs = []
        for unit in self.__list:
            try:
                self.__place = self.read_bytes(unit[0], unit[1])
                if not first_found:
                    for match in re.finditer(self.value, self.__place, re.DOTALL):
                        list_of_addrs.append(unit[0] + match.span()[0])
                else:
                    for match in re.finditer(self.value, self.__place, re.DOTALL):
                        return unit[0] + match.span()[0]
            except Exception:
                pass
        if first_found:
            return None
        else:
            return list_of_addrs

    def scan_pattern_in_raw(self, first_addr: int, final_address: int, pattern: str, first_found: bool = False):
        """Ищет адреса с заданными байтам в заданном диапазоне. Работает с rb"bytes" вместо b"bytes".

        Search address with given bytes in given region. Work with rb"bytes" instead of b"bytes".

        >>> # Получение списка адресов
        >>> # Для получения первого подходящего адреса передаем аргумент return_first_found=True
        >>> # В случае с одиночным поиском возвращает int или None вместо списка
        >>> # Getting list of addresses
        >>> # For getting first suitable address give extra argument return_first_found=True
        >>> # Return int or None if work with single address search
        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> found_addresses = process.raw_pattern_scan(0, 0xFFFFFF, "14 00 00 00 FF FF")
        [0x80fcc8, 0x80fdac]
        """

        region_scan = first_addr

        self.__pattern = pattern.strip().split(" ")

        if not pattern.count("?"):
            self.__pattern = bytes.fromhex("".join(self.__pattern))
        else:
            pattern_next = b""
            for byte in self.__pattern:
                if byte == "??":
                    pattern_next += b'.'
                else:
                    pattern_next += b'\\' + 'x'.encode() + byte.encode()
            self.__pattern = pattern_next

        self.__list = []
        allowed_protections = [D, F, H, G]
        while region_scan < final_address:
            get_mem_region = request_ex(self.handle, region_scan)
            region_scan = get_mem_region.Addr + get_mem_region.RangeSize
            if not (
                    get_mem_region.Piece != C or get_mem_region.Defense not in allowed_protections):
                self.__list.append(
                    (get_mem_region.Addr, get_mem_region.RangeSize))

        list_of_addrs = []
        for unit in self.__list:
            try:
                self.__place = self.read_bytes(unit[0], unit[1])
                if not first_found:
                    for match in re.finditer(self.__pattern, self.__place, re.DOTALL):
                        list_of_addrs.append(unit[0] + match.span()[0])
                else:
                    for match in re.finditer(self.__pattern, self.__place, re.DOTALL):
                        return unit[0] + match.span()[0]
            except Exception:
                pass
        if first_found:
            return None
        else:
            return list_of_addrs

    # Чтение памяти
    def read_bytes(self, addr: int, length: int):
        r"""Читает заданое количество байт по данному адресу.

        Read given length of bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_bytes(0x80FCC8, 4)
        b'\x14\x00\x00\x00'
        """

        buffer = ctypes.create_string_buffer(length)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), length,
                                                 ctypes.byref(bytes_read))
        return buffer.raw

    def read_short(self, addr: int):
        """Читает 2 байта по данному адресу.

        Read 2 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_short(0x80FCC8)
        20
        """

        buffer = ctypes.create_string_buffer(2)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 2,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<h', buffer.raw)[0]

    def read_ushort(self, addr: int):
        """Читает 2 байта по данному адресу.

        Read 2 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_ushort(0x80FCC8)
        20
        """

        buffer = ctypes.create_string_buffer(2)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 2,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<H', buffer.raw)[0]

    def read_long(self, addr: int):
        """Читает 4 байта по данному адресу.

        Read 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_long(0x80FCC8)
        20
        """

        buffer = ctypes.create_string_buffer(4)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 4,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<l', buffer.raw)[0]

    def read_ulong(self, addr: int):
        """Читает 4 байта по данному адресу.

        Read 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_ulong(0x80FCC8)
        20
        """

        buffer = ctypes.create_string_buffer(4)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 4,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<L', buffer.raw)[0]

    def read_longlong(self, addr: int):
        """Читает 8 байтов по данному адресу.

        Read 8 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_longlong(0x80FCC8)
        -4294967276
        """

        buffer = ctypes.create_string_buffer(8)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 8,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<q', buffer.raw)[0]

    def read_ulonglong(self, addr: int):
        """Читает 8 байтов по данному адресу.

        Read 8 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_ulonglong(0x80FCC8)
        18446744069414584340
        """

        buffer = ctypes.create_string_buffer(8)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 8,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<Q', buffer.raw)[0]

    def read_int(self, addr: int):
        """Читает 4 байта по данному адресу.

        Read 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_int(0x80FCC8)
        20
        """

        buffer = ctypes.create_string_buffer(4)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 4,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<i', buffer.raw)[0]

    def read_uint(self, addr: int):
        """Читает 4 байта по данному адресу.

        Read 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_uint(0x80FCC8)
        20
        """

        buffer = ctypes.create_string_buffer(4)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 4,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<I', buffer.raw)[0]

    def read_float(self, addr: int):
        """Читает 4 байта по данному адресу.

        Read 4 bytes by given address.
        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_float(0xCF6928)
        3.140625
        """

        buffer = ctypes.create_string_buffer(4)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 4,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<f', buffer.raw)[0]

    def read_double(self, addr: int):
        """Читает 8 байтов по данному адресу.

        Read 8 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> value = process.read_double(0x80F288)
        10.5
        """

        buffer = ctypes.create_string_buffer(8)
        bytes_read = ctypes.c_size_t()
        ctypes.windll.kernel32.ReadProcessMemory(self.handle, ctypes.c_void_p(addr), ctypes.byref(buffer), 8,
                                                 ctypes.byref(bytes_read))
        return struct.unpack('<d', buffer.raw)[0]

    # Запись памяти
    def write_bytes(self, addr: int, value: bytes):
        r"""Записывает данные байты по данному адресу.

        Write given length of bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_bytes(0x3BB6490, b"\x00\x00\x00\x00\x00\x00\x39\x40")
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, value, len(value), 0x0)

    def write_float(self, addr: int, value: float):
        """Записывает 4 байта по данному адресу.

        Write 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_float(0x3BB6490, 3.14)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('f', value), 4, 0x0)

    def write_double(self, addr: int, value: float):
        """Записывает 8 байтов по данному адресу.

        Write 8 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_double(0x3BB6490, 3.14)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('d', value), 8, 0x0)

    def write_short(self, addr: int, value: int):
        """Записывает 2 байта по данному адресу.

        Write 2 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_short(0x3BB6490, 1337)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('h', value), 2, 0x0)

    def write_ushort(self, addr: int, value: int):
        """Записывает 2 байта по данному адресу.

        Write 2 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_ushort(0x3BB6490, 1337)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('H', value), 2, 0x0)

    def write_long(self, addr: int, value: int):
        """Записывает 4 байта по данному адресу.

        Write 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_long(0x3BB6490, 1337)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('l', value), 4, 0x0)

    def write_ulong(self, addr: int, value: int):
        """Записывает 4 байта по данному адресу.

        Write 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_ulong(0x3BB6490, 1337)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('L', value), 4, 0x0)

    def write_longlong(self, addr: int, value: int):
        """Записывает 8 байтов по данному адресу.

        Write 8 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_longlong(0x3BB6490, 1337)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('q', value), 8, 0x0)

    def write_ulonglong(self, addr: int, value: int):
        """Записывает 8 байтов по данному адресу.

        Write 8 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_ulonglong(0x3BB6490, 1337)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('Q', value), 8, 0x0)

    def write_int(self, addr: int, value: int):
        """Записывает 4 байта по данному адресу.

        Write 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_int(0x3BB6490, 1337)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('i', value), 4, 0x0)

    def write_uint(self, addr: int, value: int):
        """Записывает 4 байта по данному адресу.

        Write 4 bytes by given address.

        >>> from raw import *
        >>> process = Process(process_name="Notepad++.exe")
        >>> process.write_uint(0x3BB6490, 1337)
        """

        writing = ctypes.cast(addr, ctypes.c_char_p)
        ctypes.windll.kernel32.WriteProcessMemory(self.handle, writing, struct.pack('I', value), 4, 0x0)

